<?php

return [
    'secret' => 'null',
    'sitekey' => 'null',
];
