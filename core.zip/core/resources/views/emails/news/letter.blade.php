<h3>{{ $title }}</h3><br>
<p>{!! $description  !!} </p>


