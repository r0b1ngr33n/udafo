<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
        th,td{
            font-size: 14px;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Date</th>
            <th>Balance Type</th>
            <th>Balance</th>
            <th>Charge</th>
            <th>Balance Details</th>
            <th>Past Balance</th>
            <th>Present Balance</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td width="18%"><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d F Y h:i A')); ?></td>
                <td width="11%">
                    <?php if($p->balance_type == 1): ?>
                        <span class="label label-info"><i class="fa fa-plus"></i> Fund Add </span>
                    <?php elseif($p->balance_type == 2): ?>
                        <span class="label label-success"><i class="fa fa-cloud-download"></i> Deposit</span>
                    <?php elseif($p->balance_type == 3): ?>
                        <span class="label label-success"><i class="fa fa-recycle"></i> Rebeat</span>
                    <?php elseif($p->balance_type == 4): ?>
                        <span class="label label-success"><i class="fa fa-reply-all"></i> Withdraw</span>
                    <?php elseif($p->balance_type == 5): ?>
                        <span class="label label-success"><i class="fa fa-user-circle-o"></i> Referral</span>
                    <?php elseif($p->balance_type == 7): ?>
                        <span class="label label-danger"><i class="fa fa-bolt"></i> Refund</span>
                    <?php elseif($p->balance_type == 8): ?>
                        <span class="label label-success"><i class="fa fa-plus"></i> Bank</span>
                    <?php endif; ?>
                </td>
                <td width="10%"><?php echo e($p->balance); ?> - <?php echo e($basic->currency); ?></td>
                <td width="9%">
                    <?php if($p->charge == null): ?>
                        <i>Null</i>
                    <?php else: ?>
                        <?php echo e($p->charge); ?> - <?php echo e($basic->currency); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($p->details); ?></td>
                <td width="12%"><?php echo e(round($p->old_balance,3)); ?> - <?php echo e($basic->currency); ?></td>
                <td width="12%"><?php echo e(round($p->new_balance,3)); ?> - <?php echo e($basic->currency); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>