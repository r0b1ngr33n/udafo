<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="<?php echo e($site_title); ?>" />
    <meta name="author" content="" />

    <link rel="icon" href="<?php echo e(asset('assets/images')); ?>/<?php echo e($general->favicon); ?>">

    <title><?php echo e($site_title); ?> | <?php echo e($page_title); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/jquery-ui-1.10.3.custom.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/font-icons/entypo/css/entypo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/font-icons/font-awesome/css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/neon-core.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/neon-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/neon-forms.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/custom.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/dashboard/css/sweetalert.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/jquery-1.11.3.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('style'); ?>

    <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


</head>
<body class="page-body  page-fade">

<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

    <div class="sidebar-menu">

        <div class="sidebar-menu-inner">

            <header class="logo-env">

                <!-- logo -->
                <div class="logo">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" width="120" alt="" />
                    </a>
                </div>

                <!-- logo collapse icon -->
                <div class="sidebar-collapse">
                    <a href="#" class="sidebar-collapse-icon"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
                        <i class="entypo-menu"></i>
                    </a>
                </div>


                <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
                <div class="sidebar-mobile-menu visible-xs">
                    <a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
                        <i class="entypo-menu"></i>
                    </a>
                </div>

            </header>


            <ul id="main-menu" class="main-menu">
                <!-- add class "multiple-expanded" to allow multiple submenus to open -->
                <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
                <li class="<?php echo e(Request::is('dashboard') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="entypo-gauge"></i>
                        <span class="title">Dashboard</span>
                    </a>

                </li>
                <li class="<?php echo e(Request::is('admin-activity') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('admin-activity')); ?>">
                        <i class="fa fa-indent"></i>
                        <span class="title">Activity Log</span>
                    </a>
                </li>
                <li class="has-sub">
                    <a href="#">
                        <span class="title"><i class="fa fa-reply-all"></i> Manage Withdraw</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('withdraw-pending')); ?>">
                                <span class="title"><i class="fa fa-spinner"></i> Withdraw Pending</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('withdraw-success')); ?>">
                                <span class="title"><i class="fa fa-check-circle"></i> Withdraw Success</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('withdraw-refund')); ?>">
                                <span class="title"><i class="fa fa-exclamation-triangle"></i> Withdraw Refund</span>
                            </a>
                        </li>

                    </ul>
                </li>
                <li class="<?php echo e(Request::is('admin-deposit') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('admin-deposit')); ?>">
                        <i class="fa fa-history"></i>
                        <span class="title">Deposit History</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('admin-rebeat') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('admin-rebeat')); ?>">
                        <i class="fa fa-history"></i>
                        <span class="title">Profit History</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('manual-payment-request') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('manual-payment-request')); ?>">
                        <i class="fa fa-cog"></i>
                        <span class="title">Manage Bank Payment</span>
                    </a>
                </li>
                <li class="has-sub">
                    <a href="#">
                        <span class="title"><i class="fa fa-users"></i> Manage Users</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('user-manage')); ?>">
                                <span class="title"><i class="fa fa-users"></i> Manage Users</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('block-user')); ?>">
                                <span class="title"><i class="fa fa-user-times"></i> Block Users</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub">
                    <a href="#">
                        <span class="title"><i class="fa fa-indent"></i> Manage Investment Plan</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('plan-create')); ?>">
                                <span class="title"><i class="entypo-plus"></i> Create New Plan</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('plan-show')); ?>">
                                <span class="title"><i class="entypo-monitor"></i> View All Plan</span>
                            </a>
                        </li>

                    </ul>
                </li>
                <li class="<?php echo e(Request::is('payment-manage') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('payment-manage')); ?>">
                        <i class="fa fa-credit-card"></i>
                        <span class="title">Payment Method</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('manual-payment') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('manual-payment')); ?>">
                        <i class="fa fa-bank"></i>
                        <span class="title">Manage Bank</span>
                    </a>
                </li>


                <li class="<?php echo e(Request::is('withdraw-payment') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('withdraw-payment')); ?>">
                        <i class="fa fa-money"></i>
                        <span class="title">Withdraw Method</span>
                    </a>
                </li>

                <li class="<?php echo e(Request::is('news-category') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('news-category')); ?>">
                        <i class="fa fa-list"></i>
                        <span class="title">News Category</span>
                    </a>
                </li>
                <li class="has-sub">
                    <a href="#">
                        <span class="title"><i class="fa fa-newspaper-o"></i> Manage News</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('news-create')); ?>">
                                <span class="title"><i class="entypo-plus"></i> Create New News</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('news-show')); ?>">
                                <span class="title"><i class="entypo-monitor"></i> View All News</span>
                            </a>
                        </li>

                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('latter-create')); ?>">
                        <span class="title"><i class="fa fa-envelope-open"></i> Send News Latter</span>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('manage-compound') ? " opened active" : ""); ?>">
                    <a href="<?php echo e(route('manage-compound')); ?>">
                        <i class="fa fa-sort-amount-asc"></i>
                        <span class="title">Manage Compound</span>
                    </a>
                </li>
                <li class="has-sub">
                    <a href="#">
                        <span class="title"><i class="fa fa-handshake-o"></i> Manage Partner</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('partner-create')); ?>">
                                <span class="title"><i class="entypo-plus"></i> Create New Partner</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('partner-show')); ?>">
                                <span class="title"><i class="entypo-monitor"></i> View All Partner</span>
                            </a>
                        </li>

                    </ul>
                </li>
                <li class="has-sub">
                    <a href="#">
                        <i class="entypo-tools"></i>
                        <span class="title">Web Control</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('basic-setting')); ?>">
                                <span class="title"><i class="entypo-cog"></i> Basic Setting</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('general-setting')); ?>">
                                <span class="title"><i class="entypo-cog"></i> General Setting</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('manage-chose')); ?>">
                                <span class="title"><i class="entypo-cog"></i> Manage Chose Us</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('manage-promo')); ?>">
                                <span class="title"><i class="entypo-cog"></i> Manage Promo</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('manage-testimonial')); ?>">
                                <span class="title"><i class="entypo-cog"></i> Manage Testimonial</span>
                            </a>
                        </li>
                        <li class="has-sub">
                            <a href="#">
                                <span class="title"><i class="entypo-cog"></i> Manage Menu</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('menu_create')); ?>">
                                        <span class="title"><i class="entypo-plus"></i> Add New</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('menu_show')); ?>">
                                        <span class="title"><i class="entypo-monitor"></i> View All</span>
                                    </a>
                                </li>

                            </ul>
                        </li>
                        <li class="has-sub">
                            <a href="#">
                                <span class="title"><i class="entypo-cog"></i> Manage Slider</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('slider-create')); ?>">
                                        <span class="title"><i class="entypo-plus"></i> Add New</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('slider-show')); ?>">
                                        <span class="title"><i class="entypo-monitor"></i> View All</span>
                                    </a>
                                </li>

                            </ul>
                        </li>
                        <li class="has-sub">
                            <a href="#">
                                <span class="title"><i class="entypo-cog"></i> Manage Web page</span>
                            </a>
                            <ul>

                                <li>
                                    <a href="<?php echo e(route('manage-about')); ?>">
                                        <span class="title"><i class="entypo-cog"></i> Manage About Page</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('manage-faq')); ?>">
                                        <span class="title"><i class="entypo-cog"></i> Manage FAQ Page</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('manage-document')); ?>">
                                        <span class="title"><i class="entypo-cog"></i> Manage Document Page</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('manage-terms')); ?>">
                                        <span class="title"><i class="entypo-cog"></i> Manage Terms & Condition</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('manage-privacy')); ?>">
                                        <span class="title"><i class="entypo-cog"></i> Manage Privacy page</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </li>

            </ul>

        </div>

    </div>

    <div class="main-content">

        <div class="row">

            <div class="col-md-6">
                <h2><?php echo e($page_title); ?></h2>
            </div>

            <!-- Profile Info and Notifications -->
            <div class="col-md-6 col-sm-6 clearfix" style="padding-right: 50px;">

                <ul class="user-info pull-right pull-none-xsm">

                    <!-- Profile Info -->
                    <li class="profile-info dropdown"><!-- add class "pull-right" if you want to place this from right -->

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img style="height: 40px" src="<?php echo e(asset('assets/images')); ?>/<?php echo e(Auth::guard('admin')->user()->image); ?>" alt="" class="img-circle" width="44" />
                            <?php echo e(Auth::guard('admin')->user()->name); ?> - ( <?php echo e($basic->symbol); ?> <?php echo e(round($basic->admin_total,3)); ?> )
                        </a>

                        <ul class="dropdown-menu">

                            <!-- Reverse Caret -->
                            <li class="caret"></li>

                            <!-- Profile sub-links -->
                            <li>
                                <a href="<?php echo e(route('edit-profile')); ?>">
                                    <i class="entypo-pencil"></i>Edit Profile
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('change-pass')); ?>">
                                    <i class="entypo-attention"></i>
                                    Change Password
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.logout')); ?>">
                                    <i class="entypo-logout right"></i> Log Out
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>


        </div>

        <hr />
        <div class="row">
            <div class="col-md-12">
                <!--  ==================================VALIDATION ERRORS==================================  -->
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo $error; ?>

                        </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!--  ==================================SESSION MESSAGES==================================  -->
            </div>
        </div>

    <?php echo $__env->yieldContent('content'); ?>


    <!-- Footer -->
        <footer class="main">

            &copy; <?php  echo date('Y');  ?> <strong>All Copyright Reserved.</strong>

        </footer>
    </div>


</div>


<!-- Bottom scripts (common) -->
<script src="<?php echo e(asset('assets/dashboard/js/TweenMax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/js/jquery-ui-1.10.3.minimal.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/js/joinable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/js/resizeable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/js/neon-api.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dashboard/js/sweetalert.min.js')); ?>"></script>

<script>
    <?php if(session()->has('message')): ?>
        swal({
        title: "<?php echo session()->get('title'); ?>",
        text: "<?php echo session()->get('message'); ?>",
        type: "<?php echo session()->get('type'); ?>",
        confirmButtonText: "OK"
    });
    <?php endif; ?>

</script>


<?php echo $__env->yieldContent('scripts'); ?>

<!-- JavaScripts initializations and stuff -->
<script src="<?php echo e(asset('assets/dashboard/js/neon-custom.js')); ?>"></script>


</body>
</html>