<?php $__env->startSection('style'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-send"></i> <strong><?php echo e($page_title); ?></strong></div>

                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-sm-4 text-center">
                                <div class="panel panel-success panel-pricing">
                                    <div class="panel-heading">
                                        <h3 style="font-size: 28px;"><b><?php echo e($p->name); ?></b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                        <p><strong><?php echo e($basic->symbol); ?><?php echo e($p->minimum); ?> - <?php echo e($basic->symbol); ?> <?php echo e($p->maximum); ?></strong></p>
                                    </div>
                                    <ul style='font-size: 15px;' class="list-group text-center bold">
                                        <li class="list-group-item"><i class="fa fa-check"></i> Fixed Charge - <?php echo e($basic->symbol); ?> <?php echo e($p->fix); ?></li>
                                        <li class="list-group-item"><i class="fa fa-check"></i> Transaction Percent - <?php echo e($p->percent); ?> <i class="fa fa-percent"></i> </li>
                                    </ul>
                                    <div class="panel-footer" style="overflow: hidden">
                                        <div class="col-sm-12">
                                            <a href="javascript:;" onclick="jQuery('#modal-<?php echo e($p->id); ?>').modal('show');" class="btn btn-info btn-block btn-icon icon-left"><i class="fa fa-send"></i> Add Fund</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->
    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modal-<?php echo e($p->id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"><i class="fa fa-send"></i> Deposit via <strong><?php echo e($p->name); ?></strong></h4>
                    </div>
                    <?php echo e(Form::open()); ?>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label style="margin-top: 5px;font-size: 14px;" class="col-sm-2 col-sm-offset-2 control-label">Amount : </label>
                                    <div class="col-sm-7">
                                        <span style="color: green;margin-left: 10px;"><strong><?php echo e($basic->symbol); ?> <?php echo e($p->minimum); ?> - <?php echo e($basic->symbol); ?> <?php echo e($p->maximum); ?>. Charge (<?php echo e($basic->symbol); ?> <?php echo e($p->fix); ?> + <?php echo e($p->percent); ?>%)</strong></span>
                                        <div class="input-group" style="margin-bottom: 15px;">
                                            <input type="text" value="" id="amount<?php echo e($p->id); ?>" name="amount" class="form-control" required>
                                            <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                            <input type="hidden" name="method_id" id="method_id<?php echo e($p->id); ?>" value="<?php echo e($p->id); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div id="result<?php echo e($p->id); ?>"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script type='text/javascript'>

            jQuery(document).ready(function(){

                $('#amount<?php echo e($p->id); ?>').on('input', function() {
                    var amount = $("#amount<?php echo e($p->id); ?>").val();
                    var method_id = $("#method_id<?php echo e($p->id); ?>").val();
                    $.post(
                            '<?php echo e(url('/fund-check-amount')); ?>',
                            {
                                _token: '<?php echo e(csrf_token()); ?>',
                                amount : amount,
                                method_id : method_id
                            },
                            function(data) {
                                $("#result<?php echo e($p->id); ?>").html(data);
                            }
                    );
                });
            });
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>